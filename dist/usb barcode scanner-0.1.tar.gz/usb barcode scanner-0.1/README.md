# usb_barcode_scanner
